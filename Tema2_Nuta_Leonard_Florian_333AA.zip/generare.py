import time
import keras_cv
import keras
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import cv2
import os
import moviepy.editor as mp
from pymediainfo import MediaInfo
import pyttsx3


# model = keras_cv.models.StableDiffusion(
#     img_width=512, img_height=512, jit_compile=False
# )
#
# images = model.text_to_image("orange apple in the sea", batch_size=1)
#
#
#
#
# def plot_images(images):
#     plt.figure(figsize=(20, 20))
#     for i in range(len(images)):
#         ax = plt.subplot(1, len(images), i + 1)
#         plt.imshow(images[i])
#         plt.axis("off")
#         plt.savefig("image.png", transparent=True, bbox_inches="tight",
#                     pad_inches=0)  # Save the figure without the white box
#
#
# plot_images(images)




def plot_rectangle_on_image(image, start_pixel, end_pixel, save_path=None): # Functie desenare dreptunghi
    fig, ax = plt.subplots(figsize=(image.shape[1] / 100, image.shape[0] / 100))

    ax.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    ax.axis("off")
    rect = patches.Rectangle(start_pixel, end_pixel[0] - start_pixel[0], end_pixel[1] - start_pixel[1], linewidth=2,
                             edgecolor='r', facecolor='none')
    ax.add_patch(rect)

    if save_path:
        plt.savefig(save_path, transparent=True, bbox_inches="tight", pad_inches=0)  # Salvare figura înainte de afișare
        plt.close()


def resize_image(image, width=None, height=None):
    current_height, current_width = image.shape[:2]
    if width is None and height is None:
        return image
    if width is None:
        new_width = int((height / current_height) * current_width)
        new_height = height
    elif height is None:
        new_height = int((width / current_width) * current_height)
        new_width = width
    else:
        new_width = width
        new_height = height
    resized_image = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_AREA)

    return resized_image


image = cv2.imread("image.png")
Nheight, Nwidth = image.shape[:2]
image_backup = cv2.imread("image.png")
cv2.imwrite('backups/image.png', image)

start_pixel = (739, 107)
end_pixel = (1537, 1219)

plot_rectangle_on_image(image, start_pixel, end_pixel, save_path="image_with_rectangle.png")
image_modifier = cv2.imread("image_with_rectangle.png")
resized_image = resize_image(image_modifier, width=Nwidth, height=Nheight)
cv2.imwrite('image_with_rectangle.png', resized_image)

image_rectangle = cv2.imread("image_with_rectangle.png")
image_rectangle_backup = cv2.imread("image_with_rectangle.png")
image_rectangle = cv2.putText(image_rectangle, 'Image with rectangle', (37,50), cv2.FONT_HERSHEY_SIMPLEX, 2,
                              (0, 255, 0), 6, cv2.LINE_AA)
cv2.imwrite("image_with_rectangle.png", image_rectangle)

image = cv2.putText(image, 'Original image with orange apple in the sea', (37,50), cv2.FONT_HERSHEY_SIMPLEX, 2,
                    (0, 255, 0), 6, cv2.LINE_AA)
cv2.imwrite("image.png", image)
image = image_backup
hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
lower_red = np.array([0, 100, 0])
upper_red = np.array([255, 255, 255])
lower_saturation = 240  # Valoare minima saturare
upper_saturation = 255  # Valoare maxima saturare
lower_value = 220  # Valoare minima luminanta
upper_value = 255  # Valoare maxima luminanta

# Creare masca pentru extragerea numai partii portocalii a imaginii
mask1 = cv2.inRange(hsv_image, lower_red, upper_red)
mask1 &= cv2.inRange(hsv_image, np.array([0, 0, lower_value]), np.array([255, 255, upper_value]))
mask2 = cv2.inRange(hsv_image, lower_red, upper_red)
mask2 &= cv2.inRange(hsv_image, np.array([0, lower_saturation, 0]), np.array([255, upper_saturation, 255]))
combined_mask = cv2.bitwise_or(mask1, mask2)

combined_image = cv2.bitwise_and(image, image, mask=combined_mask)
cv2.imwrite("backups/image_object.png", combined_image)
combined_image = cv2.putText(combined_image, 'Mask with object', (37,50), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 0), 6,
                             cv2.LINE_AA)

cv2.imwrite('image_object.png', combined_image)



# Binarizare
image_bin = cv2.imread("image_object.png", cv2.IMREAD_GRAYSCALE)

# Am ales pragul 150
_, binary_image = cv2.threshold(image_bin, 150, 255, cv2.THRESH_BINARY)

_, binary_image_backup = cv2.threshold(image_bin, 150, 255, cv2.THRESH_BINARY)
binary_image = cv2.putText(binary_image, 'Binary Image', (37,50), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 6,
                           cv2.LINE_AA)
cv2.imwrite('image_binary.png', binary_image)

image_bgr = cv2.imread("backups/image.png", cv2.IMREAD_COLOR)
combined_image_bgr = cv2.imread("backups/image_object.png", cv2.IMREAD_COLOR)


# CIE XYZ
xyz_image1 = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2XYZ)
xyz_image1 = cv2.putText(xyz_image1, 'CIE XYZ Original', (37,50), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 6,
                         cv2.LINE_AA)
cv2.imwrite('image_xyz1.png', xyz_image1)

xyz_image2 = cv2.cvtColor(combined_image_bgr, cv2.COLOR_BGR2XYZ)
xyz_image2 = cv2.putText(xyz_image2, 'CIE XYZ Object', (37,50), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 6,
                         cv2.LINE_AA)
cv2.imwrite('image_xyz2.png', xyz_image2)




def images_to_video(input_folder, output_video, fps):
    input_folder = os.getcwd()

    images = [img for img in os.listdir(input_folder) if img.endswith(".jpg") or img.endswith(".png")]
    images.sort()

    first_image = cv2.imread(os.path.join(input_folder, images[0]))
    height, width, _ = first_image.shape

    # Motion JPEG
    fourcc = cv2.VideoWriter_fourcc(*'MJPG')  # Codec-ul Motion JPEG
    out = cv2.VideoWriter(output_video, fourcc, fps, (width, height))

    for image in images:
        img_path = os.path.join(input_folder, image)
        frame = cv2.imread(img_path)


        for _ in range(int(fps * 1.85)):  # Astfel, fiecare imagine va sta 1.85 secunde (ca sa sincronizam audio-ul)
            out.write(frame)
    out.release()

input_folder = "ImaginiVideo"
output_video = "video.mp4"
fps = 24
images_to_video(input_folder, output_video, fps)

engine = pyttsx3.init()
# engine.say("Original image with apple in the sea")
# engine.runAndWait()
# time.sleep(1)
# engine.say("Binary Image")
# engine.runAndWait()
# time.sleep(1)
# engine.say("Mask with object")
# engine.runAndWait()
# time.sleep(1)
# engine.say("Image with rectangle")
# engine.runAndWait()
# time.sleep(1)
# engine.say("CIE XYZ Original")
# engine.runAndWait()
# time.sleep(1)
# engine.say("CIE XYZ Object")
# engine.runAndWait()
engine.stop()

engine.save_to_file(
    'Original image with orange apple in the sea. Binary Image. Mask with object. Image with rectangle. CIE XYZ Original. CIE XYZ Object. aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
    'audio.mp3')
engine.runAndWait() # Acel "aaaaaaaa" l-am pus pentru ca fisierul audio sa fie mai lung decat videoclip-ul, pentru taierea cu succes la lungimea sa

video_file_name = "video.mp4"

# Citire container video, selectare metadate
media_info = MediaInfo.parse(video_file_name)
for track in media_info.tracks:
    if track.track_type == "Video":
        duration = track.duration
        fps = int(float(track.frame_rate))

# Taiem un fisier audio pentru a avea fix durata video-ului
audioclip = mp.AudioFileClip("audio.mp3").subclip(0, duration / 1000)
video_clip = mp.VideoFileClip(video_file_name)
video_clip = video_clip.set_audio(audioclip)
video_clip.write_videofile("edited_video.mp4", fps=fps)

engine.stop()
audioclip.close()